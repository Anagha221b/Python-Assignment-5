try:
    
    user_input = input("Enter a list of integers separated by spaces: ")
    
    numbers = list(map(int, user_input.split()))
    
    average = sum(numbers) / len(numbers)
    print(f"The average of the entered numbers is: {average}")

except Exception as e:
    print(f"An error occurred: {e}")

finally:
    print("The program has finished running.")
