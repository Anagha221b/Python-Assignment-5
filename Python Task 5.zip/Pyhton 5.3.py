with open('C:/Users/2273622/OneDrive - Cognizant/Documents/2273622_Apache_spark_casestudy.txt', 'r') as file:
   
    contents = file.read()

words = contents.split()
 
word_count = len(words)

print(f'Total number of words: {word_count}')
