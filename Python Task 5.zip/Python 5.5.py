
user_input = input("Please enter a list of integers separated by spaces: ")

try:
    numbers = list(map(int, user_input.split()))
    
    for number in numbers:
        if number < 0:
            raise ValueError(f"Negative integer found: {number}")
    
    print("All integers are non-negative.")
except ValueError as e:
    print(e)
