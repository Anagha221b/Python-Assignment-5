with open('C:/Users/2273622/OneDrive - Cognizant/Documents/TASK#6.txt', 'r') as file:
    contents = file.read()
print(contents)
