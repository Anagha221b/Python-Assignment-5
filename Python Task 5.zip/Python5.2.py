
with open('C:/Users/2273622/Downloads/Source.txt', 'r') as source_file:
   
    contents = source_file.read()


with open('C:/Users/2273622/Downloads/Destination.txt', 'w') as destination_file:
   
    destination_file.write(contents)

