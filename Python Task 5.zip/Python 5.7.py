
    try:
        # Prompt the user to input a filename
        filename = input("Enter the filename: ")
        
        # Prompt the user to input a string to write to the file
        content = input("Enter the content to write to the file: ")
        
        # Open the file in write mode and write the content
        with open(filename, 'w') as file:
            file.write(content)
        
        # Print a welcome message if no exception occurred
        print("Welcome! The content has been successfully written to the file.")
    
    except Exception as e:
        # Handle any exceptions that might occur
        print(f"An error occurred: {e}")
    
    finally:
        print("The program has finished running.")
