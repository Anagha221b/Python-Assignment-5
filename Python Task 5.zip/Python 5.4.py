
user_input = input("Please enter a number: ")

try:
    number = int(user_input)
    print(f"The integer value is: {number}")
except ValueError:
    print("Invalid input! Please enter a valid integer.")
